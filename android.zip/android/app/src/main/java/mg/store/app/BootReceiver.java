package mg.store.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c, Intent i) { if (BuildConfig.NOTIFS) NotifJob.schedule(c);
        try {
            Intent si = new Intent(c, OrderWatchService.class);
            if (android.os.Build.VERSION.SDK_INT >= 26) c.startForegroundService(si); else c.startService(si);
        } catch (Throwable ignored) {}
    }
}
