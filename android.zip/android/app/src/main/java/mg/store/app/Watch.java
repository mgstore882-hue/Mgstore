package mg.store.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.BitmapFactory;
import android.os.Build;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Iterator;
import java.util.TimeZone;

/** Vérifie la base (Firebase) et affiche les notifications Android. */
public class Watch {
    static final String DB = "https://mg-store-882-default-rtdb.firebaseio.com";
    static final String CH = "mg_notifs";
    static final String Q = "?orderBy=%22%24key%22&limitToLast=5";
    static final String Q100 = "?orderBy=%22%24key%22&limitToLast=100";

    static SharedPreferences sp(Context c) { return c.getSharedPreferences("mgn", Context.MODE_PRIVATE); }

    /** Date de première utilisation: on ne notifie pas l'historique ancien. */
    static long t0(Context c) {
        SharedPreferences p = sp(c);
        long t = p.getLong("t0", 0);
        if (t == 0) { t = System.currentTimeMillis(); p.edit().putLong("t0", t).apply(); }
        return t;
    }

    static String get(String path) throws Exception {
        HttpURLConnection h = (HttpURLConnection) new URL(DB + path).openConnection();
        h.setConnectTimeout(10000);
        h.setReadTimeout(10000);
        BufferedReader r = new BufferedReader(new InputStreamReader(h.getInputStream(), "UTF-8"));
        StringBuilder sb = new StringBuilder();
        String ln;
        while ((ln = r.readLine()) != null) sb.append(ln);
        r.close();
        return sb.toString().trim();
    }

    static JSONObject getJson(String path) {
        try {
            String t = get(path);
            if (t.isEmpty() || t.equals("null")) return null;
            return new JSONObject(t);
        } catch (Throwable e) { return null; }
    }

    static ArrayList<String> sortedKeys(JSONObject o) {
        ArrayList<String> keys = new ArrayList<String>();
        Iterator<String> it = o.keys();
        while (it.hasNext()) keys.add(it.next());
        Collections.sort(keys);
        return keys;
    }

    static void show(Context c, int id, String title, String body) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(new NotificationChannel(CH, "Notifications", NotificationManager.IMPORTANCE_HIGH));
        }
        Intent i = new Intent(c, MainActivity.class).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(c, id, i,
                PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(c, CH) : new Notification.Builder(c);
        b.setSmallIcon(R.drawable.ic_notif)
                .setLargeIcon(BitmapFactory.decodeResource(c.getResources(), R.drawable.logo_round))
                .setContentTitle(title).setContentText(body)
                .setStyle(new Notification.BigTextStyle().bigText(body))
                .setAutoCancel(true).setContentIntent(pi);
        if (Build.VERSION.SDK_INT < 26) b.setPriority(Notification.PRIORITY_HIGH).setDefaults(Notification.DEFAULT_ALL);
        try { nm.notify(id, b.build()); } catch (Throwable ignored) {}
    }

    /** Notifie les entrées de path plus récentes que la dernière vue (et postérieures à since). */
    static int notifyNew(Context c, String path, String prefKey, long since, int baseId) {
        JSONObject o = getJson(path + Q);
        if (o == null) return 0;
        SharedPreferences p = sp(c);
        String last = p.getString(prefKey, "");
        ArrayList<String> keys = sortedKeys(o);
        int shown = 0;
        for (String k : keys) {
            if (k.compareTo(last) <= 0) continue;
            JSONObject n = o.optJSONObject(k);
            if (n == null || n.optLong("ts", 0) < since || n.optString("title").isEmpty()) continue;
            if (shown < 3) show(c, baseId + shown, n.optString("title"), n.optString("body"));
            shown++;
        }
        if (!keys.isEmpty()) p.edit().putString(prefKey, keys.get(keys.size() - 1)).apply();
        return shown;
    }

    /** Boutique ouverte ? (mode auto: 5h-23h, heure de Madagascar). */
    static boolean shopOpen() {
        JSONObject st = getJson("/status.json");
        String mode = st == null ? "auto" : st.optString("mode", "");
        if (mode.equals("on")) return true;
        if (mode.equals("off")) return false;
        if (st != null && mode.isEmpty() && st.has("online")) return st.optBoolean("online", true);
        int h = (Calendar.getInstance(TimeZone.getTimeZone("UTC")).get(Calendar.HOUR_OF_DAY) + 3) % 24;
        return h >= 5 && h < 23;
    }

    /** CLIENT: notifications diffusées, personnelles (commande terminée/annulée) et état de la boutique. */
    static void checkClient(Context c, boolean launch) {
        try {
            long since = t0(c);
            SharedPreferences p = sp(c);
            notifyNew(c, "/notifs.json", "lastG", since, 5000);
            checkReplies(c);
            checkPromo(c);
            String uid = p.getString("uid", "");
            if (!uid.isEmpty()) {
                long us = p.getLong("since_" + uid, since);
                notifyNew(c, "/unotifs/" + URLEncoder.encode(uid, "UTF-8") + ".json", "lastU_" + uid, us, 5100);
            }
            boolean open = shopOpen();
            String prev = p.getString("shop", "");
            long at = p.getLong("shopAt", 0);
            boolean changed = !prev.isEmpty() && !prev.equals(open ? "1" : "0");
            boolean stale = launch && (prev.isEmpty() || System.currentTimeMillis() - at > 6L * 3600 * 1000);
            if (changed || stale) {
                if (open) show(c, 5200, "Boutique en ligne", "MG STORE est ouverte : passez votre commande, livraison en 5 à 10 minutes.");
                else show(c, 5200, "Boutique hors ligne", "MG STORE est fermée pour le moment : vos commandes seront livrées à la réouverture.");
                p.edit().putLong("shopAt", System.currentTimeMillis()).apply();
            }
            p.edit().putString("shop", open ? "1" : "0").apply();
        } catch (Throwable ignored) {}
    }

    /** CLIENT: nouvelle réponse du support (messages dont dev = cet appareil/compte). */
    static void checkReplies(Context c) {
        try {
            SharedPreferences p = sp(c);
            String dev = p.getString("dev", "");
            if (dev.isEmpty()) return;
            JSONObject o = getJson("/messages.json?orderBy=%22dev%22&equalTo=%22" + URLEncoder.encode(dev, "UTF-8") + "%22");
            if (o == null || o.has("error")) o = getJson("/messages.json" + Q100);
            if (o == null || o.has("error")) return;
            String key = "lastRep_" + dev;
            long last = p.getLong(key, -1), mx = 0;
            int cnt = 0; String text = "";
            Iterator<String> it = o.keys();
            while (it.hasNext()) {
                JSONObject m = o.optJSONObject(it.next());
                if (m == null || !dev.equals(m.optString("dev")) || m.optString("reply").isEmpty()) continue;
                long at = m.optLong("replyAt", 0);
                if (at > mx) mx = at;
                if (last >= 0 && at > last) { cnt++; text = m.optString("reply"); }
            }
            if (last < 0) { p.edit().putLong(key, Math.max(mx, System.currentTimeMillis())).apply(); return; }
            if (cnt > 0) show(c, 5300, "Nouvelle réponse de MG STORE", text);
            if (mx > last) p.edit().putLong(key, mx).apply();
        } catch (Throwable ignored) {}
    }

    /** CLIENT: nouvelle réduction de prix => notification (plus de bandeau sur l'accueil). */
    static void checkPromo(Context c) {
        try {
            JSONObject o = getJson("/promo.json");
            SharedPreferences p = sp(c);
            boolean init = p.getBoolean("promoInit", false);
            String seen = p.getString("promoSeen", "|");
            long now = System.currentTimeMillis();
            int n = 0;
            if (o != null) {
                Iterator<String> it = o.keys();
                while (it.hasNext()) {
                    String k = it.next();
                    JSONObject pr = o.optJSONObject(k);
                    if (pr == null) continue;
                    int pct = pr.optInt("pct", 0);
                    long end = pr.optLong("end", 0);
                    if (pct <= 0 || (end > 0 && end <= now)) continue;
                    String sig = k + ":" + pct + ":" + end;
                    if (seen.contains("|" + sig + "|")) continue;
                    seen += sig + "|";
                    if (init && n < 3) {
                        String label = pr.optString("label", "");
                        if (label.isEmpty()) { String g = pr.optString("game", k); label = "ALL".equals(g) ? "Tous les jeux" : g; }
                        String body = label;
                        if (end > 0) {
                            java.text.SimpleDateFormat f = new java.text.SimpleDateFormat("dd/MM 'à' HH:mm", java.util.Locale.FRANCE);
                            f.setTimeZone(TimeZone.getTimeZone("Indian/Antananarivo"));
                            body += " · jusqu'au " + f.format(new java.util.Date(end));
                        }
                        show(c, 5400 + n, "🔥 Promo -" + pct + "%", body);
                        n++;
                    }
                }
            }
            if (seen.length() > 1500) seen = "|" + seen.substring(seen.length() - 1000);
            p.edit().putString("promoSeen", seen).putBoolean("promoInit", true).apply();
        } catch (Throwable ignored) {}
    }

    /** ADMIN: nouveaux messages des clients. */
    static void checkAdminMsgs(Context c) {
        try {
            long since = t0(c);
            JSONObject o = getJson("/messages.json?orderBy=%22%24key%22&limitToLast=10");
            if (o == null || o.has("error")) return;
            SharedPreferences p = sp(c);
            String last = p.getString("lastM", "");
            ArrayList<String> keys = sortedKeys(o);
            int shown = 0;
            for (String k : keys) {
                if (k.compareTo(last) <= 0) continue;
                JSONObject m = o.optJSONObject(k);
                if (m == null || m.optLong("ts", 0) < since || m.optBoolean("adminOnly", false) || !m.optString("reply").isEmpty()) continue;
                String txt = m.optString("message").replaceFirst("^\\[SUPPORT\\]\\s*", "");
                if (shown < 3) show(c, 6100 + shown, "Nouveau message 💬", m.optString("pseudo", "Client") + " : " + txt);
                shown++;
            }
            if (!keys.isEmpty()) p.edit().putString("lastM", keys.get(keys.size() - 1)).apply();
        } catch (Throwable ignored) {}
    }

    /** ADMIN: nouvelles commandes. */
    static void checkAdmin(Context c) {
        try {
            long since = t0(c);
            JSONObject o = getJson("/commandes.json" + Q);
            if (o == null) return;
            SharedPreferences p = sp(c);
            String last = p.getString("lastA", "");
            ArrayList<String> keys = sortedKeys(o);
            int shown = 0;
            for (String k : keys) {
                if (k.compareTo(last) <= 0) continue;
                JSONObject n = o.optJSONObject(k);
                if (n == null || n.optLong("ts", 0) < since || n.optBoolean("done", false) || n.optBoolean("annule", false)) continue;
                String body = n.optString("jeu") + " — " + n.optString("pack") + " · " + n.optString("pr") + " Ar";
                if (shown < 3) show(c, 6000 + shown, "Nouvelle commande 🛒", body);
                shown++;
            }
            if (!keys.isEmpty()) p.edit().putString("lastA", keys.get(keys.size() - 1)).apply();
        } catch (Throwable ignored) {}
    }
}
