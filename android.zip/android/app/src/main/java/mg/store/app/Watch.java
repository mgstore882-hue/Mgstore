package mg.store.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.BitmapFactory;
import android.os.Build;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Iterator;
import java.util.TimeZone;

/** Vérifie la base (Firebase) et affiche les notifications Android. */
public class Watch {
    static final String DB = "https://mg-store-882-default-rtdb.firebaseio.com";
    static final String CH = "mg_notifs";
    static final String Q = "?orderBy=%22%24key%22&limitToLast=5";

    static SharedPreferences sp(Context c) { return c.getSharedPreferences("mgn", Context.MODE_PRIVATE); }

    /** Date de première utilisation: on ne notifie pas l'historique ancien. */
    static long t0(Context c) {
        SharedPreferences p = sp(c);
        long t = p.getLong("t0", 0);
        if (t == 0) { t = System.currentTimeMillis(); p.edit().putLong("t0", t).apply(); }
        return t;
    }

    static String get(String path) throws Exception {
        HttpURLConnection h = (HttpURLConnection) new URL(DB + path).openConnection();
        h.setConnectTimeout(10000);
        h.setReadTimeout(10000);
        BufferedReader r = new BufferedReader(new InputStreamReader(h.getInputStream(), "UTF-8"));
        StringBuilder sb = new StringBuilder();
        String ln;
        while ((ln = r.readLine()) != null) sb.append(ln);
        r.close();
        return sb.toString().trim();
    }

    static JSONObject getJson(String path) {
        try {
            String t = get(path);
            if (t.isEmpty() || t.equals("null")) return null;
            return new JSONObject(t);
        } catch (Throwable e) { return null; }
    }

    static ArrayList<String> sortedKeys(JSONObject o) {
        ArrayList<String> keys = new ArrayList<String>();
        Iterator<String> it = o.keys();
        while (it.hasNext()) keys.add(it.next());
        Collections.sort(keys);
        return keys;
    }

    static void show(Context c, int id, String title, String body) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(new NotificationChannel(CH, "Notifications", NotificationManager.IMPORTANCE_HIGH));
        }
        Intent i = new Intent(c, MainActivity.class).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(c, id, i,
                PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(c, CH) : new Notification.Builder(c);
        b.setSmallIcon(R.drawable.ic_notif)
                .setLargeIcon(BitmapFactory.decodeResource(c.getResources(), R.drawable.logo_round))
                .setContentTitle(title).setContentText(body)
                .setStyle(new Notification.BigTextStyle().bigText(body))
                .setAutoCancel(true).setContentIntent(pi);
        if (Build.VERSION.SDK_INT < 26) b.setPriority(Notification.PRIORITY_HIGH).setDefaults(Notification.DEFAULT_ALL);
        try { nm.notify(id, b.build()); } catch (Throwable ignored) {}
    }

    /** Notifie les entrées de path plus récentes que la dernière vue (et postérieures à since). */
    static int notifyNew(Context c, String path, String prefKey, long since, int baseId) {
        JSONObject o = getJson(path + Q);
        if (o == null) return 0;
        SharedPreferences p = sp(c);
        String last = p.getString(prefKey, "");
        ArrayList<String> keys = sortedKeys(o);
        int shown = 0;
        for (String k : keys) {
            if (k.compareTo(last) <= 0) continue;
            JSONObject n = o.optJSONObject(k);
            if (n == null || n.optLong("ts", 0) < since || n.optString("title").isEmpty()) continue;
            if (shown < 3) show(c, baseId + shown, n.optString("title"), n.optString("body"));
            shown++;
        }
        if (!keys.isEmpty()) p.edit().putString(prefKey, keys.get(keys.size() - 1)).apply();
        return shown;
    }

    /** Boutique ouverte ? (mode auto: 5h-23h, heure de Madagascar). */
    static boolean shopOpen() {
        JSONObject st = getJson("/status.json");
        String mode = st == null ? "auto" : st.optString("mode", "");
        if (mode.equals("on")) return true;
        if (mode.equals("off")) return false;
        if (st != null && mode.isEmpty() && st.has("online")) return st.optBoolean("online", true);
        int h = (Calendar.getInstance(TimeZone.getTimeZone("UTC")).get(Calendar.HOUR_OF_DAY) + 3) % 24;
        return h >= 5 && h < 23;
    }

    /** CLIENT: notifications diffusées, personnelles (commande terminée/annulée) et état de la boutique. */
    static void checkClient(Context c, boolean launch) {
        try {
            long since = t0(c);
            SharedPreferences p = sp(c);
            notifyNew(c, "/notifs.json", "lastG", since, 5000);
            String uid = p.getString("uid", "");
            if (!uid.isEmpty()) {
                long us = p.getLong("since_" + uid, since);
                notifyNew(c, "/unotifs/" + URLEncoder.encode(uid, "UTF-8") + ".json", "lastU_" + uid, us, 5100);
            }
            boolean open = shopOpen();
            String prev = p.getString("shop", "");
            long at = p.getLong("shopAt", 0);
            boolean changed = !prev.isEmpty() && !prev.equals(open ? "1" : "0");
            boolean stale = launch && (prev.isEmpty() || System.currentTimeMillis() - at > 6L * 3600 * 1000);
            if (changed || stale) {
                if (open) show(c, 5200, "Boutique en ligne", "MG STORE est ouverte : passez votre commande maintenant, elle sera traitée rapidement.");
                else show(c, 5200, "Boutique fermée", "MG STORE est fermée pour le moment. Vos commandes seront traitées dès la réouverture (5h).");
                p.edit().putLong("shopAt", System.currentTimeMillis()).apply();
            }
            p.edit().putString("shop", open ? "1" : "0").apply();
        } catch (Throwable ignored) {}
    }

    /** ADMIN: nouvelles commandes. */
    static void checkAdmin(Context c) {
        try {
            long since = t0(c);
            JSONObject o = getJson("/commandes.json" + Q);
            if (o == null) return;
            SharedPreferences p = sp(c);
            String last = p.getString("lastA", "");
            ArrayList<String> keys = sortedKeys(o);
            int shown = 0;
            for (String k : keys) {
                if (k.compareTo(last) <= 0) continue;
                JSONObject n = o.optJSONObject(k);
                if (n == null || n.optLong("ts", 0) < since || n.optBoolean("done", false) || n.optBoolean("annule", false)) continue;
                String body = n.optString("jeu") + " — " + n.optString("pack") + " · " + n.optString("pr") + " Ar";
                if (shown < 3) show(c, 6000 + shown, "Nouvelle commande 🛒", body);
                shown++;
            }
            if (!keys.isEmpty()) p.edit().putString("lastA", keys.get(keys.size() - 1)).apply();
        } catch (Throwable ignored) {}
    }
}
