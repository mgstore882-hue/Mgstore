package mg.store.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Handler;
import android.content.SharedPreferences;
import androidx.browser.customtabs.CustomTabsIntent;
import androidx.webkit.WebViewAssetLoader;

/** Charge le site embarqué (assets) : s'ouvre même sans connexion, jamais d'écran blanc. */
public class MainActivity extends Activity {
    private static final String HOST = "appassets.androidplatform.net";
    private WebView web;
    private boolean pageReady = false;

    private class Bridge {
        @JavascriptInterface public void googleLogin() {
            runOnUiThread(new Runnable() { public void run() {
                Uri u = Uri.parse(BuildConfig.SITE_URL + "/google.html?app=1");
                try {
                    CustomTabsIntent ct = new CustomTabsIntent.Builder().setShowTitle(true).build();
                    ct.launchUrl(MainActivity.this, u);
                } catch (Throwable t) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Throwable ignored) {}
                }
            }});
        }
        @JavascriptInterface public void setUser(String uid) {
            try {
                if (uid == null || uid.length() > 200) return;
                SharedPreferences p = Watch.sp(MainActivity.this);
                String old = p.getString("uid", "");
                if (!old.equals(uid)) {
                    SharedPreferences.Editor e = p.edit().putString("uid", uid);
                    if (!uid.isEmpty() && !p.contains("since_" + uid)) e.putLong("since_" + uid, System.currentTimeMillis());
                    e.apply();
                }
            } catch (Throwable ignored) {}
        }
    }

    private void handleDeepLink(Intent in) {
        try {
            if (in == null || in.getData() == null) return;
            Uri d = in.getData();
            if (!"mgstore".equals(d.getScheme())) return;
            String t = d.getQueryParameter("t");
            if (t == null || !t.matches("[A-Za-z0-9._-]+")) return;
            final String js = "(function f(){if(window.authGoogleToken)authGoogleToken('" + t + "');else setTimeout(f,300)})()";
            if (web != null) web.evaluateJavascript(js, null);
        } catch (Throwable ignored) {}
    }

    @Override protected void onNewIntent(Intent in) { super.onNewIntent(in); handleDeepLink(in); }


    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        try {
            getWindow().setStatusBarColor(Color.BLACK);
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        } catch (Throwable ignored) {}

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .setDomain(HOST)
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        web = new WebView(this);
        web.setBackgroundColor(Color.BLACK);
        web.setVisibility(View.INVISIBLE);            // le logo boribory (splash) reste visible pendant le chargement
        setContentView(web, new ViewGroup.LayoutParams(-1, -1));
        web.addJavascriptInterface(new Bridge(), "AndroidBridge");

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setUserAgentString(s.getUserAgentString() + " MGStoreApp");
        CookieManager.getInstance().setAcceptCookie(true);

        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                return loader.shouldInterceptRequest(r.getUrl());
            }
            @Override public void onPageFinished(WebView v, String url) {
                if (pageReady) return;
                pageReady = true;
                new Handler().postDelayed(new Runnable() { public void run() {
                    web.setAlpha(0f); web.setVisibility(View.VISIBLE); web.animate().alpha(1f).setDuration(250).start();
                }}, 350);
            }
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if (HOST.equals(u.getHost())) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Throwable ignored) {}
                return true;
            }
        });

        if (b != null) web.restoreState(b);
        else web.loadUrl("https://" + HOST + "/assets/" + BuildConfig.START_PAGE);
        // sécurité: ne jamais rester sur l'écran noir
        new Handler().postDelayed(new Runnable() { public void run() { if (!pageReady) { pageReady = true; web.setVisibility(View.VISIBLE); } }}, 8000);

        if (BuildConfig.NOTIFS) {
            if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 7);
            NotifJob.schedule(this);
            Watch.t0(this);
            if (BuildConfig.WATCH_ORDERS) {
                try { startService(new Intent(this, OrderWatchService.class)); } catch (Throwable ignored) {}
            } else {
                new Thread(new Runnable() { public void run() { Watch.checkClient(getApplicationContext(), true); }}).start();
            }
        }
        handleDeepLink(getIntent());
    }

    @Override protected void onSaveInstanceState(Bundle o) { super.onSaveInstanceState(o); if (web != null) web.saveState(o); }
    @Override protected void onResume() { super.onResume(); if (web != null) web.onResume(); }
    @Override protected void onPause() { if (web != null) web.onPause(); super.onPause(); }
    @Override public void onBackPressed() { if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
