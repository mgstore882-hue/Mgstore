package mg.store.app;

import android.app.Activity;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.provider.Settings;
import android.os.PowerManager;
import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Handler;
import android.content.SharedPreferences;
import androidx.browser.customtabs.CustomTabsIntent;
import androidx.webkit.WebViewAssetLoader;

/** Charge le site embarqué (assets) : s'ouvre même sans connexion, jamais d'écran blanc. */
public class MainActivity extends Activity {
    private static final String HOST = "appassets.androidplatform.net";
    private WebView web;
    private boolean pageReady = false;
    private ValueCallback<Uri[]> fileCb;

    private class Bridge {
        @JavascriptInterface public void googleLogin() {
            runOnUiThread(new Runnable() { public void run() {
                Uri u = Uri.parse(BuildConfig.SITE_URL + "/google.html?app=1");
                try {
                    CustomTabsIntent ct = new CustomTabsIntent.Builder().setShowTitle(true).build();
                    ct.launchUrl(MainActivity.this, u);
                } catch (Throwable t) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Throwable ignored) {}
                }
            }});
        }
        /** « Mettre à jour » sans quitter l'app : télécharge la dernière page depuis le site puis recharge. */
        @JavascriptInterface public void applyUpdate() {
            new Thread(new Runnable() { public void run() {
                boolean ok = false;
                try {
                    String base = BuildConfig.SITE_URL;
                    while (base.endsWith("/")) base = base.substring(0, base.length() - 1);
                    HttpURLConnection c = (HttpURLConnection) new URL(base + "/" + BuildConfig.START_PAGE + "?t=" + System.currentTimeMillis()).openConnection();
                    c.setConnectTimeout(15000); c.setReadTimeout(30000); c.setUseCaches(false);
                    c.setRequestProperty("Cache-Control", "no-cache");
                    if (c.getResponseCode() == 200) {
                        ByteArrayOutputStream bo = new ByteArrayOutputStream();
                        InputStream in = c.getInputStream();
                        byte[] buf = new byte[16384]; int n;
                        while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
                        in.close();
                        byte[] data = bo.toByteArray();
                        if (data.length > 20000 && new String(data, "UTF-8").contains("</html>")) {
                            File f = new File(getFilesDir(), "live_" + BuildConfig.START_PAGE);
                            File tmp = new File(getFilesDir(), "live_" + BuildConfig.START_PAGE + ".tmp");
                            FileOutputStream fo = new FileOutputStream(tmp);
                            fo.write(data); fo.close();
                            if (f.exists()) f.delete();
                            ok = tmp.renameTo(f);
                        }
                    }
                } catch (Throwable ignored) {}
                final boolean r = ok;
                runOnUiThread(new Runnable() { public void run() {
                    if (r) { web.clearCache(false); web.reload(); }
                    else web.evaluateJavascript("window.__updDone&&window.__updDone(false)", null);
                }});
            }}).start();
        }
        @JavascriptInterface public void openUrl(final String url) {
            runOnUiThread(new Runnable() { public void run() {
                try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch (Throwable ignored) {}
            }});
        }
        @JavascriptInterface public void setDev(String dev) {
            try {
                if (dev == null || dev.length() > 200) return;
                Watch.sp(MainActivity.this).edit().putString("dev", dev).apply();
            } catch (Throwable ignored) {}
        }
        @JavascriptInterface public void setUser(String uid) {
            try {
                if (uid == null || uid.length() > 200) return;
                SharedPreferences p = Watch.sp(MainActivity.this);
                String old = p.getString("uid", "");
                if (!old.equals(uid)) {
                    SharedPreferences.Editor e = p.edit().putString("uid", uid);
                    if (!uid.isEmpty() && !p.contains("since_" + uid)) e.putLong("since_" + uid, System.currentTimeMillis());
                    e.apply();
                }
            } catch (Throwable ignored) {}
        }
    }

    private void handleDeepLink(Intent in) {
        try {
            if (in == null || in.getData() == null) return;
            Uri d = in.getData();
            if (!"mgstore".equals(d.getScheme())) return;
            String t = d.getQueryParameter("t");
            if (t == null || !t.matches("[A-Za-z0-9._-]+")) return;
            final String js = "(function f(){if(window.authGoogleToken)authGoogleToken('" + t + "');else setTimeout(f,300)})()";
            if (web != null) web.evaluateJavascript(js, null);
        } catch (Throwable ignored) {}
    }

    /** Une seule fois : demande d'exclure l'app de l'optimisation batterie (notifications fiables app fermée). */
    private void askBattery() {
        try {
            if (Build.VERSION.SDK_INT < 23) return;
            final SharedPreferences p = Watch.sp(this);
            if (p.getBoolean("battAsked", false)) return;
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            if (pm == null || pm.isIgnoringBatteryOptimizations(getPackageName())) return;
            new Handler().postDelayed(new Runnable() { public void run() {
                try {
                    p.edit().putBoolean("battAsked", true).apply();
                    startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + getPackageName())));
                } catch (Throwable ignored) {}
            }}, 6000);
        } catch (Throwable ignored) {}
    }

    @Override protected void onNewIntent(Intent in) { super.onNewIntent(in); handleDeepLink(in); }


    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        try {
            getWindow().setStatusBarColor(Color.BLACK);
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        } catch (Throwable ignored) {}

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .setDomain(HOST)
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        try { // nouvelle version d'APK => on repart des fichiers intégrés (pas de vieille page « live »)
            SharedPreferences vp = Watch.sp(this);
            if (vp.getInt("vc", 0) != BuildConfig.VERSION_CODE) {
                new File(getFilesDir(), "live_" + BuildConfig.START_PAGE).delete();
                vp.edit().putInt("vc", BuildConfig.VERSION_CODE).apply();
            }
        } catch (Throwable ignored) {}
        web = new WebView(this);
        web.setBackgroundColor(Color.BLACK);
        web.setVisibility(View.INVISIBLE);            // le logo boribory (splash) reste visible pendant le chargement
        setContentView(web, new ViewGroup.LayoutParams(-1, -1));
        web.addJavascriptInterface(new Bridge(), "AndroidBridge");

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setUserAgentString(s.getUserAgentString() + " MGStoreApp");
        CookieManager.getInstance().setAcceptCookie(true);

        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileCb != null) { try { fileCb.onReceiveValue(null); } catch (Throwable ignored) {} }
                fileCb = cb;
                try { startActivityForResult(p.createIntent(), 91); }
                catch (Throwable t) { fileCb = null; return false; }
                return true;
            }
        });
        web.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                Uri uu = r.getUrl();
                if (HOST.equals(uu.getHost()) && ("/assets/" + BuildConfig.START_PAGE).equals(uu.getPath())) {
                    File lf = new File(getFilesDir(), "live_" + BuildConfig.START_PAGE);
                    if (lf.exists()) { try { return new WebResourceResponse("text/html", "utf-8", new FileInputStream(lf)); } catch (Throwable ignored) {} }
                }
                return loader.shouldInterceptRequest(uu);
            }
            @Override public void onPageFinished(WebView v, String url) {
                if (pageReady) return;
                pageReady = true;
                new Handler().postDelayed(new Runnable() { public void run() {
                    web.setAlpha(0f); web.setVisibility(View.VISIBLE); web.animate().alpha(1f).setDuration(250).start();
                }}, 350);
            }
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if (HOST.equals(u.getHost())) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Throwable ignored) {}
                return true;
            }
        });

        if (b != null) web.restoreState(b);
        else web.loadUrl("https://" + HOST + "/assets/" + BuildConfig.START_PAGE);
        // sécurité: ne jamais rester sur l'écran noir
        new Handler().postDelayed(new Runnable() { public void run() { if (!pageReady) { pageReady = true; web.setVisibility(View.VISIBLE); } }}, 8000);

        if (BuildConfig.NOTIFS) {
            if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 7);
            NotifJob.schedule(this);
            Watch.t0(this);
            try {
                Intent si = new Intent(this, OrderWatchService.class);
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(si); else startService(si);
            } catch (Throwable ignored) {}
            if (!BuildConfig.WATCH_ORDERS) {
                new Thread(new Runnable() { public void run() { Watch.checkClient(getApplicationContext(), true); }}).start();
            }
            askBattery();
        }
        handleDeepLink(getIntent());
    }

    @Override protected void onActivityResult(int rq, int rs, Intent d) {
        if (rq == 91) {
            if (fileCb != null) {
                Uri[] r = null;
                try { r = WebChromeClient.FileChooserParams.parseResult(rs, d); } catch (Throwable ignored) {}
                fileCb.onReceiveValue(r);
                fileCb = null;
            }
            return;
        }
        super.onActivityResult(rq, rs, d);
    }

    @Override protected void onSaveInstanceState(Bundle o) { super.onSaveInstanceState(o); if (web != null) web.saveState(o); }
    @Override protected void onResume() { super.onResume(); if (web != null) web.onResume(); }
    @Override protected void onPause() { if (web != null) web.onPause(); super.onPause(); }
    @Override public void onBackPressed() { if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
