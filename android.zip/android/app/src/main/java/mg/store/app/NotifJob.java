package mg.store.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.job.JobInfo;
import android.app.job.JobParameters;
import android.app.job.JobScheduler;
import android.app.job.JobService;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

/** Vérifie périodiquement (≈15 min) les nouvelles notifications, même application fermée. */
public class NotifJob extends JobService {
    static final String DB = "https://mg-store-882-default-rtdb.firebaseio.com";
    static final String CH = "mg_notifs";
    static final int JOB_ID = 4201;

    public static void schedule(Context c) {
        try {
            JobScheduler js = (JobScheduler) c.getSystemService(Context.JOB_SCHEDULER_SERVICE);
            if (js == null) return;
            for (JobInfo j : js.getAllPendingJobs()) if (j.getId() == JOB_ID) return;
            JobInfo.Builder b = new JobInfo.Builder(JOB_ID, new ComponentName(c, NotifJob.class))
                    .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                    .setPeriodic(15 * 60 * 1000L)
                    .setPersisted(true);
            js.schedule(b.build());
        } catch (Throwable ignored) {}
    }

    @Override public boolean onStartJob(final JobParameters p) {
        new Thread(new Runnable() { public void run() {
            try { check(getApplicationContext()); } catch (Throwable ignored) {}
            jobFinished(p, false);
        }}).start();
        return true;
    }
    @Override public boolean onStopJob(JobParameters p) { return true; }

    static void check(Context c) throws Exception {
        URL u = new URL(DB + "/notifs.json?orderBy=%22%24key%22&limitToLast=5");
        HttpURLConnection h = (HttpURLConnection) u.openConnection();
        h.setConnectTimeout(10000); h.setReadTimeout(10000);
        BufferedReader r = new BufferedReader(new InputStreamReader(h.getInputStream(), "UTF-8"));
        StringBuilder sb = new StringBuilder(); String ln;
        while ((ln = r.readLine()) != null) sb.append(ln);
        r.close();
        String txt = sb.toString().trim();
        if (txt.equals("null") || txt.isEmpty()) return;
        JSONObject o = new JSONObject(txt);
        ArrayList<String> keys = new ArrayList<String>();
        Iterator<String> it = o.keys();
        while (it.hasNext()) keys.add(it.next());
        Collections.sort(keys);
        SharedPreferences sp = c.getSharedPreferences("mgn", Context.MODE_PRIVATE);
        String last = sp.getString("last", null);
        if (keys.isEmpty()) return;
        String newest = keys.get(keys.size() - 1);
        if (last == null) { sp.edit().putString("last", newest).apply(); return; } // 1er lancement: pas de rafale
        int shown = 0;
        for (String k : keys) {
            if (k.compareTo(last) <= 0) continue;
            JSONObject n = o.optJSONObject(k);
            if (n == null || n.optString("title").isEmpty()) continue;
            show(c, 5000 + (shown++), n.optString("title"), n.optString("body"));
        }
        sp.edit().putString("last", newest).apply();
    }

    static void show(Context c, int id, String title, String body) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(new NotificationChannel(CH, "Notifications MG STORE", NotificationManager.IMPORTANCE_HIGH));
        }
        Intent i = new Intent(c, MainActivity.class).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(c, id, i, PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(c, CH) : new Notification.Builder(c);
        b.setSmallIcon(R.drawable.ic_notif).setContentTitle(title).setContentText(body)
                .setStyle(new Notification.BigTextStyle().bigText(body))
                .setAutoCancel(true).setContentIntent(pi);
        if (Build.VERSION.SDK_INT < 26) b.setPriority(Notification.PRIORITY_HIGH).setDefaults(Notification.DEFAULT_ALL);
        nm.notify(id, b.build());
    }
}
