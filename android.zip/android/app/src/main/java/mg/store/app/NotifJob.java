package mg.store.app;

import android.app.job.JobInfo;
import android.app.job.JobParameters;
import android.app.job.JobScheduler;
import android.app.job.JobService;
import android.content.ComponentName;
import android.content.Context;

/** Vérification périodique (≈15 min), même application fermée. */
public class NotifJob extends JobService {
    static final int JOB_ID = 4201;

    public static void schedule(Context c) {
        try {
            JobScheduler js = (JobScheduler) c.getSystemService(Context.JOB_SCHEDULER_SERVICE);
            if (js == null) return;
            for (JobInfo j : js.getAllPendingJobs()) if (j.getId() == JOB_ID) return;
            JobInfo.Builder b = new JobInfo.Builder(JOB_ID, new ComponentName(c, NotifJob.class))
                    .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                    .setPeriodic(15 * 60 * 1000L)
                    .setPersisted(true);
            js.schedule(b.build());
        } catch (Throwable ignored) {}
    }

    @Override public boolean onStartJob(final JobParameters p) {
        new Thread(new Runnable() { public void run() {
            try {
                Context c = getApplicationContext();
                if (BuildConfig.WATCH_ORDERS) { Watch.checkAdmin(c); Watch.checkAdminMsgs(c); } else Watch.checkClient(c, false);
            } catch (Throwable ignored) {}
            jobFinished(p, false);
        }}).start();
        return true;
    }
    @Override public boolean onStopJob(JobParameters p) { return true; }
}
