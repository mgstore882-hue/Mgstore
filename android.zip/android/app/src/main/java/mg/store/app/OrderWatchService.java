package mg.store.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;

/** Service au premier plan (admin): vérifie les nouvelles commandes toutes les 20 secondes. */
public class OrderWatchService extends Service {
    private volatile boolean run = false;

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public int onStartCommand(Intent in, int flags, int startId) {
        try {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (Build.VERSION.SDK_INT >= 26) {
                nm.createNotificationChannel(new NotificationChannel("mg_watch", "Surveillance des commandes", NotificationManager.IMPORTANCE_LOW));
            }
            Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, "mg_watch") : new Notification.Builder(this);
            b.setSmallIcon(R.drawable.ic_notif).setContentTitle("MG ADMIN").setContentText("Surveillance des nouvelles commandes").setOngoing(true);
            Notification n = b.build();
            if (Build.VERSION.SDK_INT >= 29) startForeground(77, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
            else startForeground(77, n);
        } catch (Throwable t) { stopSelf(); return START_NOT_STICKY; }
        if (!run) {
            run = true;
            new Thread(new Runnable() { public void run() {
                while (OrderWatchService.this.run) {
                    Watch.checkAdmin(getApplicationContext());
                    try { Thread.sleep(20000); } catch (InterruptedException e) { break; }
                }
            }}).start();
        }
        return START_STICKY;
    }

    @Override public void onDestroy() { run = false; super.onDestroy(); }
}
